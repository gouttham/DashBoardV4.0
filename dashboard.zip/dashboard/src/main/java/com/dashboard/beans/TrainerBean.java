package com.dashboard.beans;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "db_Trainer")
public class TrainerBean {

	@Id
	private String courseId;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "trainerId")
	private CredentialBean trainerId;
	private String title;
	private int skillId;
	private Date startDate;
	private Date endDate;
	private Date updatedOn;
	private String updatedBy;

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public CredentialBean getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(CredentialBean trainerId) {
		this.trainerId = trainerId;
	}

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return "TrainerBean [courseId=" + courseId + ", trainerId=" + trainerId + ", title=" + title + ", skillId="
				+ skillId + ", startDate=" + startDate + ", endDate=" + endDate + ", updatedOn=" + updatedOn
				+ ", updatedBy=" + updatedBy + "]";
	}
	

}
