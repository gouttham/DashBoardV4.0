package com.dashboard.beans;



import org.springframework.web.multipart.MultipartFile;

public class Sample {

	private MultipartFile f;

	public MultipartFile getF() {
		return f;
	}

	public void setF(MultipartFile f) {
		this.f = f;
	}

	
	
}
